package com.example.cube.Components;

public class UserInformation {
    public String name;
    public String address;

    public UserInformation(String name, String address) {
        this.name = name;
        this.address = address;
    }

    public UserInformation () {

    }
}
