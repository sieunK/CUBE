package com.example.cube.Components;

import java.util.Date;

public class Comments {

    private String uid;
    private String author;
    private String body;
    private Date date;

    public Comments(){}
    public Comments(String uid, String author, String body, Date date) {
        this.uid = uid;
        this.author = author;
        this.body = body;
        this.date = date;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
