package com.example.cube.Components;

public class AppUser {
    private String email;
    private String username;
    private int point;
    public AppUser(){}

    public AppUser(String email, String username, int point) {
        this.email = email;
        this.username = username;
        this.point = point;
    }

    @Override
    public String toString() {
        return "AppUser{" +
                "email='" + email + '\'' +
                ", username='" + username + '\'' +
                ", point=" + point +
                '}';
    }

    public int getPoint() {
        return point;
    }

    public void setPoint(int point) {
        this.point = point;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        username = username;
    }
}
